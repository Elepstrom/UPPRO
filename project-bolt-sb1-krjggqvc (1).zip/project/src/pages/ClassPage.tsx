import React, { useState } from 'react';
import { Class, Student } from '../types';
import { History, ArrowLeft, Edit, Info } from 'lucide-react';
import { StudentDetailsModal } from '../components/modals/StudentDetailsModal';
import { EditAbsencesModal } from '../components/modals/EditAbsencesModal';
import { RFIDHistoryModal } from '../components/modals/RFIDHistoryModal';
import { ActionButton } from '../components/ActionButton';
import { SearchBar } from '../components/SearchBar';
import { exportClassToPDF } from '../services/pdfExport';
import { AnimatedDownloadIcon } from '../components/AnimatedDownloadIcon';
import { StudentList } from '../components/StudentList';
import { ClassHeader } from '../components/ClassHeader';

interface ClassPageProps {
  classData: Class;
  onBack: () => void;
}

export const ClassPage: React.FC<ClassPageProps> = ({ classData, onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [showRFIDHistory, setShowRFIDHistory] = useState<Student | null>(null);
  const [students, setStudents] = useState<Student[]>(classData.students);

  const filteredStudents = students.filter(
    (student) =>
      student.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.matricule.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSaveAbsences = (justifiedHours: number, unjustifiedHours: number) => {
    if (!editingStudent) return;

    const updatedStudents = students.map((student) =>
      student.id === editingStudent.id
        ? {
            ...student,
            justifiedAbsences: justifiedHours,
            unjustifiedAbsences: unjustifiedHours,
          }
        : student
    );

    setStudents(updatedStudents);
    setEditingStudent(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 bg-white dark:bg-gray-900 min-h-screen transition-colors duration-200">
      <ClassHeader
        classData={classData}
        onBack={onBack}
        onExport={() => exportClassToPDF(classData)}
        onShowRFIDHistory={() => selectedStudent && setShowRFIDHistory(selectedStudent)}
        hasSelectedStudent={!!selectedStudent}
      />

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
          <SearchBar
            value={searchTerm}
            onChange={setSearchTerm}
            placeholder="Rechercher un étudiant..."
          />
        </div>

        <StudentList
          students={filteredStudents}
          onEdit={setEditingStudent}
          onSelect={setSelectedStudent}
        />
      </div>

      {selectedStudent && (
        <StudentDetailsModal
          student={selectedStudent}
          onClose={() => setSelectedStudent(null)}
        />
      )}

      {editingStudent && (
        <EditAbsencesModal
          student={editingStudent}
          onClose={() => setEditingStudent(null)}
          onSave={handleSaveAbsences}
        />
      )}

      {showRFIDHistory && (
        <RFIDHistoryModal
          student={showRFIDHistory}
          onClose={() => setShowRFIDHistory(null)}
        />
      )}
    </div>
  );
};