import React, { useState } from 'react';
import { Student } from '../../types';
import { BaseModal } from './BaseModal';
import { ActionButton } from '../ActionButton';
import { Save, X, Plus, Trash2, Calendar } from 'lucide-react';
import { format, addDays, startOfWeek } from 'date-fns';
import { fr } from 'date-fns/locale';

interface WeeklyAbsence {
  id: number;
  startDate: Date;
  justifiedHours: number;
  unjustifiedHours: number;
}

interface EditAbsencesModalProps {
  student: Student;
  onClose: () => void;
  onSave: (justifiedHours: number, unjustifiedHours: number) => void;
}

export const EditAbsencesModal: React.FC<EditAbsencesModalProps> = ({
  student,
  onClose,
  onSave,
}) => {
  const [weeks, setWeeks] = useState<WeeklyAbsence[]>([
    {
      id: 1,
      startDate: new Date(),
      justifiedHours: student.justifiedAbsences,
      unjustifiedHours: student.unjustifiedAbsences,
    },
  ]);

  const addWeek = () => {
    const newWeek: WeeklyAbsence = {
      id: weeks.length + 1,
      startDate: new Date(),
      justifiedHours: 0,
      unjustifiedHours: 0,
    };
    setWeeks([...weeks, newWeek]);
  };

  const removeWeek = (weekId: number) => {
    setWeeks(weeks.filter(week => week.id !== weekId));
  };

  const updateWeek = (weekId: number, field: string, value: any) => {
    setWeeks(weeks.map(week => {
      if (week.id === weekId) {
        return { ...week, [field]: value };
      }
      return week;
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const totalJustified = weeks.reduce((sum, week) => sum + week.justifiedHours, 0);
    const totalUnjustified = weeks.reduce((sum, week) => sum + week.unjustifiedHours, 0);
    onSave(totalJustified, totalUnjustified);
  };

  const getWeekRange = (startDate: Date) => {
    const weekStart = startOfWeek(startDate, { locale: fr });
    const weekEnd = addDays(weekStart, 6);
    return `${format(weekStart, 'dd/MM/yyyy')} - ${format(weekEnd, 'dd/MM/yyyy')}`;
  };

  return (
    <BaseModal
      title={`Modifier les absences - ${student.firstName} ${student.lastName}`}
      onClose={onClose}
      maxWidth="max-w-2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">
            Gestion des absences par semaine
          </h3>
          <ActionButton
            icon={Plus}
            label="Ajouter une semaine"
            onClick={addWeek}
            variant="secondary"
          />
        </div>

        <div className="space-y-4">
          {weeks.map((week) => (
            <div
              key={week.id}
              className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg space-y-4 animate-slideUp"
            >
              <div className="flex justify-between items-center">
                <h4 className="text-md font-medium text-gray-700 dark:text-gray-300">
                  Semaine {week.id}
                </h4>
                {weeks.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeWeek(week.id)}
                    className="text-red-500 hover:text-red-600 p-1"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                )}
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Date de début de semaine
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      value={format(week.startDate, 'yyyy-MM-dd')}
                      onChange={(e) => updateWeek(week.id, 'startDate', new Date(e.target.value))}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md 
                        focus:ring-2 focus:ring-orange-500 focus:border-orange-500 dark:bg-gray-700 
                        dark:text-white transition-all duration-200"
                    />
                    <Calendar className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
                  </div>
                  <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                    Période: {getWeekRange(week.startDate)}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Heures justifiées
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={week.justifiedHours}
                      onChange={(e) => updateWeek(week.id, 'justifiedHours', Number(e.target.value))}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md 
                        focus:ring-2 focus:ring-orange-500 focus:border-orange-500 dark:bg-gray-700 
                        dark:text-white transition-all duration-200"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Heures non justifiées
                    </label>
                    <input
                      type="number"
                      min="0"
                      value={week.unjustifiedHours}
                      onChange={(e) => updateWeek(week.id, 'unjustifiedHours', Number(e.target.value))}
                      className="w-full px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-md 
                        focus:ring-2 focus:ring-orange-500 focus:border-orange-500 dark:bg-gray-700 
                        dark:text-white transition-all duration-200"
                    />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-end space-x-3 mt-6">
          <ActionButton
            icon={X}
            label="Annuler"
            onClick={onClose}
            variant="secondary"
          />
          <ActionButton
            icon={Save}
            label="Enregistrer"
            onClick={handleSubmit}
            variant="primary"
          />
        </div>
      </form>
    </BaseModal>
  );
};