import React from 'react';
import { LineChart } from './LineChart';
import { AbsenceStats } from './AbsenceStats';

interface StudentStatsProps {
  studentId: string;
}

export const StudentStats: React.FC<StudentStatsProps> = () => {
  // Données simulées pour la démonstration
  const weeklyData = {
    labels: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven'],
    datasets: [
      {
        label: 'Présences',
        data: [6, 4, 6, 5, 6],
        borderColor: 'rgb(34, 197, 94)',
        tension: 0.3,
      },
      {
        label: 'Absences',
        data: [0, 2, 0, 1, 0],
        borderColor: 'rgb(239, 68, 68)',
        tension: 0.3,
      },
    ],
  };

  const monthlyData = {
    labels: ['Sem 1', 'Sem 2', 'Sem 3', 'Sem 4'],
    datasets: [
      {
        label: 'Présences',
        data: [28, 26, 27, 25],
        borderColor: 'rgb(34, 197, 94)',
        tension: 0.3,
      },
      {
        label: 'Absences',
        data: [2, 4, 3, 5],
        borderColor: 'rgb(239, 68, 68)',
        tension: 0.3,
      },
    ],
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <AbsenceStats title="Cette semaine" data={weeklyData} />
        <AbsenceStats title="Ce mois" data={monthlyData} />
      </div>
      <div className="bg-white p-4 rounded-lg shadow">
        <LineChart data={monthlyData} />
      </div>
    </div>
  );
};